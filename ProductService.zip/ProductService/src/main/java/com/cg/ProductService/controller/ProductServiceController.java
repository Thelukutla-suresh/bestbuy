package com.cg.ProductService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.ProductService.dto.ProductName;
import com.cg.ProductService.dto.ProductPrice;
import com.cg.ProductService.dto.ProductService;

@RestController
@RequestMapping("/service")
public class ProductServiceController {
	
	@Autowired
	RestTemplate restTemplate;

	@GetMapping("/all")
	public ProductService getAll() {
		ProductName name = restTemplate.getForObject("http://localhost:9152/productname/name?pid=1", ProductName.class);
		ProductPrice price = restTemplate.getForObject("http://localhost:9125/productorder/price?pid=1", ProductPrice.class);
		return new ProductService(1,name.getProdName(),price.getProdPrice());
	}
}
