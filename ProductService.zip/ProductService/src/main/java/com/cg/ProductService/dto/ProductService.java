package com.cg.ProductService.dto;

public class ProductService {
	
	private Integer prodId;
	private String prodName;
	private Double prodPrice;

	public ProductService() {
	}

	public ProductService(Integer prodId, String prodName, Double prodPrice) {
		this.prodId = prodId;
		this.prodName = prodName;
		this.prodPrice = prodPrice;
	}

	public Integer getProdId() {
		return prodId;
	}

	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public Double getProdPrice() {
		return prodPrice;
	}

	public void setProdPrice(Double prodPrice) {
		this.prodPrice = prodPrice;
	}

	
	

}
