package com.cg.ProductService.dto;

public class ProductPrice {
	
	private Integer prodId;
	private Double prodPrice;
	
	public ProductPrice() {
	}

	public ProductPrice(Integer prodId, Double prodPrice) {
		this.prodId = prodId;
		this.prodPrice = prodPrice;
	}

	public Integer getProdId() {
		return prodId;
	}

	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}

	public Double getProdPrice() {
		return prodPrice;
	}

	public void setProdPrice(Double prodPrice) {
		this.prodPrice = prodPrice;
	}
	
	

}
