package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.employeemanagement1")
public class EmployeeManagement1Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagement1Application.class, args);
		System.out.println("Ammu");
	}

}
