package com.cg.employeemanagement1.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.employeemanagement1.dto.Employee;


@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(Employee.class);
	}

	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return mongoTemplate.insert(emp);
	}

	@Override
	public Employee searchEmployeeById(Integer empId) {
		// TODO Auto-generated method stub
		/* return mongoTemplate.findById(empId, Employee.class); */
		Query query=Query.query(Criteria.where("empId").is(empId));
		Employee emp=mongoTemplate.findOne(query, Employee.class);
		return emp;
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		mongoTemplate.save(emp);
		return emp;
	}

	@Override
	public void deleteEmployee(Integer empId) {
		// TODO Auto-generated method stub
		Employee emp=mongoTemplate.findById(empId, Employee.class);
		mongoTemplate.remove(emp);
	}
	
	

}
