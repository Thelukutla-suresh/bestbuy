package com.cg.employeemanagement1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employeemanagement1.dto.Employee;
import com.cg.employeemanagement1.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@GetMapping("/getall")
	public ResponseEntity<List<Employee>> getAllEmployee() {
		List<Employee> myList=employeeService.getAllEmployee();
		if(myList.isEmpty()) {
			return new ResponseEntity("No employee found....!!!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Employee>>(myList,HttpStatus.OK);
	}
	
	@PostMapping("/add")
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee emp) {
		Employee data= employeeService.addEmployee(emp);
		if(data==null) {
			return new ResponseEntity("Data not added...!!",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Employee>(emp,HttpStatus.OK);
		
	}
	
	@PutMapping("/update")
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee emp) {
		 Employee data=employeeService.updateEmployee(emp);
		 if(data==null)
		 {
		  return new ResponseEntity("data updated",HttpStatus.NOT_FOUND);
		 }
		 return new ResponseEntity<Employee>(emp,HttpStatus.OK);
		 
	}
	
	@DeleteMapping("/delete")
	public ResponseEntity<Employee> deleteEmployee(@RequestParam("id") Integer empId){
		  Integer data=employeeService.deleteEmployee(empId);
		  if(data==null) {
		   return new ResponseEntity(empId+" is not available",HttpStatus.NOT_FOUND);
		  }
		  return new ResponseEntity<Employee>(HttpStatus.OK); 
	}
	
	@GetMapping("/search")
	public ResponseEntity<Employee> searchEmployee(@RequestParam("id") Integer empId){
		  Employee data=employeeService.searchEmployeeById(empId);
		  if(data==null) {
		   return new ResponseEntity(empId+" is not available",HttpStatus.NOT_FOUND);
		  }
		  return new ResponseEntity<Employee>(data,HttpStatus.OK); 
	}
	

}
