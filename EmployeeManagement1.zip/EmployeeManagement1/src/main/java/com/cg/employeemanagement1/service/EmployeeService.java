package com.cg.employeemanagement1.service;

import java.util.List;

import com.cg.employeemanagement1.dto.Employee;

public interface EmployeeService {
	
	public List<Employee> getAllEmployee();
	
	public Employee addEmployee(Employee emp);
	
	public Employee searchEmployeeById(Integer empId);
	
	public Employee updateEmployee(Employee emp);
	
	public Integer deleteEmployee(Integer empId);

}
