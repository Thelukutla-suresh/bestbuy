package com.cg.employeemanagement1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employeemanagement1.dao.EmployeeDao;
import com.cg.employeemanagement1.dto.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeDao employeeDao;

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return employeeDao.getAllEmployee();
	}

	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return employeeDao.addEmployee(emp);
	}

	@Override
	public Employee searchEmployeeById(Integer empId) {
		// TODO Auto-generated method stub
		return employeeDao.searchEmployeeById(empId);
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return employeeDao.updateEmployee(emp);
	}

	@Override
	public Integer deleteEmployee(Integer empId) {
		// TODO Auto-generated method stub
		employeeDao.deleteEmployee(empId);
		return empId;
	}

}
