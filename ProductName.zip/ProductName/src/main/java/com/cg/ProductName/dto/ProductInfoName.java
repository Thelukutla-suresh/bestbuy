package com.cg.ProductName.dto;

public class ProductInfoName {
	
	private Integer prodId;
	private String prodName;
	
	public ProductInfoName() {
		
	}

	public ProductInfoName(Integer prodId, String prodName) {
		super();
		this.prodId = prodId;
		this.prodName = prodName;
	}

	public Integer getProdId() {
		return prodId;
	}

	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	
	

}
