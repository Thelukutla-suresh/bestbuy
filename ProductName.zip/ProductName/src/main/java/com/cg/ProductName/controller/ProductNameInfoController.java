package com.cg.ProductName.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ProductName.dto.ProductInfoName;

@RestController
@RequestMapping("/productname")
public class ProductNameInfoController {

	@GetMapping("/name")
	public ProductInfoName getAllProductNames(@RequestParam("pid") Integer prodId) {
		return new ProductInfoName(prodId,"Mobile");
	}
}
