package com.cg.catalogue.service;

import java.io.BufferedReader;
import java.io.File;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.cg.catalogue.dao.CustomerDao;
import com.cg.catalogue.dto.Customer;

@Service

public class CustomerService {
	
	@Autowired
	CustomerDao dao;
	String line=" ";
	
	public Customer saveCustomer(Customer cust) throws IOException {
	
		/*
		 * Customer cust=new Customer(); try { BufferedReader br=new BufferedReader(new
		 * FileReader("file1")); while((line=br.readLine())!=null) { String
		 * []data=line.split(","); cust.setFile(data[0]);
		 * cust.setLogo(file1.getBytes()); dao.save(cust); } } catch
		 * (FileNotFoundException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */
		 
		return dao.save(cust);
	}

}