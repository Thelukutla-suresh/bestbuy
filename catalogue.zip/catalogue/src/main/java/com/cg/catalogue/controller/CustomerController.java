package com.cg.catalogue.controller;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cg.catalogue.dto.Customer;
import com.cg.catalogue.service.CustomerService;

@RestController
@RequestMapping("/customer")
@CrossOrigin(origins="http://localhost:4200") 
public class CustomerController {

	@Autowired
	CustomerService service;
	
	@PostMapping("/saveUserProfile")
	public ResponseEntity<String> saveProfile(@RequestParam("file") MultipartFile file1) throws IOException{
		
		/*
		 * System.out.println("lllyyy"+file1); Customer cust=new Customer();
		 * cust.setName(name);(file1.getBytes());
		 * cust.setFile(file1.getOriginalFilename());
		 */
		
		 
		
		String line,name="C:\\Users\\madamadh\\Desktop\\"+file1.getOriginalFilename();
		//List<Customer> cust=new ArrayList<>();
		FileReader fr=new FileReader(name);
		
		/* BufferedReader br=new BufferedReader(new FileReader("filepath")); */
	    BufferedReader br=new BufferedReader(fr);
	    Customer cust1=new Customer();
		/* FileInputStream inputstream=(FileInputStream) file1.getInputStream(); */
		while((line=br.readLine())!=null) { 
			Customer cust=new Customer();
			String []data=line.split(",");
			cust.setName(data[0]);
			cust.setId(Integer.parseInt(data[1]));
			cust.setAddress(data[2]);
			cust1=service.saveCustomer(cust);
		}
		
		if(cust1!=null)
			return new ResponseEntity<String>("User saved",HttpStatus.OK);
		return new ResponseEntity<String>("not saved",HttpStatus.NOT_FOUND);
		
	}
}
