import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class CatalogueService {
  userName: string;
  customer: any;
  orderDetails:any[];
  cartDetails:any[];
  constructor(private http: HttpClient) { }

  registerCustomer(user) {
    let input = { "customerName": user.name, "email": user.email, "password": user.password, "securityQuestion": user.securityQuestion, "securityAnswer": user.securityAnswer };
    return this.http.post("http://localhost:9834/customer/register", input);
  }

  loginUser(userCredentials) {
    this.userName = userCredentials.name;
    let password = userCredentials.password;
    let role = userCredentials.role;
    if (role=="customer") {
      return this.http.get("http://localhost:9834/customer/login?username="+this.userName+"&password="+password);
    }
    return this.http.get("http://localhost:9834/admin/login?userName=" + this.userName + "&password=" + password);
  }

  setCustomer(customer: any) {
    this.customer = customer;
  }

  saveProfile(file: File): Observable<any> {
    const formdata = new FormData();
    formdata.append('file', file);
    console.log(file);
    return this.http.post("http://localhost:9834/admin/addproduct", formdata, {
      reportProgress: true,
      responseType: 'text'
    });

  }

  getCustomer() {
    return this.customer;
  }
  forgotPassword(userCredentials) {
    this.userName = userCredentials.name;
    let securityQuestion = userCredentials.securityQuestion;
    let securityAnswer = userCredentials.securityAnswer;
    return this.http.get("http://localhost:9834/customer/forgotpassword?userName=" + this.userName + "&securityQuestion=" + securityQuestion + "&securityAnswer=" + securityAnswer);

  }

  changePassword(newCredentials) {
    let password = newCredentials.password;
    return this.http.get("http://localhost:9834/customer/changepassword?userName=" + this.userName + "&password=" + password);
  }

  getAllProducts() {
    return this.http.get("http://localhost:9834/customer/getallproducts");
  }

  deleteProduct(productId){
    return this.http.delete("http://localhost:9834/admin/deleteproduct?productId="+productId);
  }

  addToCart(productId) {
    return this.http.get("http://localhost:9834/customer/cart?userName="+this.userName+"&productId="+productId);
  }

  getCartDetails() {
    this.customer=this.getCustomer();
    this.userName=this.customer.email;
    return this.http.get("http://localhost:9834/customer/getcartdetails?userName="+this.userName);
  }

  deleteProductFromCart(productId) {
    this.customer=this.getCustomer();
    this.userName=this.customer.email;
    return this.http.delete("http://localhost:9834/customer/deleteproductfromcart?userName="+this.userName+"&productId="+productId);
   }

   confirmOrder()
   {
    this.customer=this.getCustomer();
    this.userName=this.customer.email;
    return this.http.get("http://localhost:9834/customer/confirmorder?userName="+this.userName);
   }

  searchProductByRange(minPrice, maxPrice) {
    return this.http.get("http://localhost:9834/customer/searchproductsbypricerange?minPrice="+minPrice+"&maxPrice="+maxPrice);
  }

  getTotalPrice(){
    return this.http.get("http://localhost:9834/customer/gettotalprice?userName="+this.userName);
  }

  setOrderDetails(orderDetails){
    this.orderDetails=orderDetails;
  }
  getOrderDetails(){
    this.customer=this.getCustomer();
    this.userName=this.customer.email;
    return this.http.get("http://localhost:9834/customer/orderdetails?userName="+this.userName);
  }

  setCartDetails(cartDetails){
    this.cartDetails=cartDetails;
  }
}
