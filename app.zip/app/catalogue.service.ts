import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CatalogueService {

  constructor(private http:HttpClient) { }

  registerCustomer(user){

    let input={"customerName":user.name, "email":user.email, "password":user.password,"securityQuestion":user.securityQuestion,"securityAnswer":user.securityAnswer};
    return this.http.post("http://localhost:9834/customer/register",input);

  }
  loginUser(userCredentials){

  }

  forgotPassword(userCredentials){

  }

  changePassword(newCredentials){

  }

  getAllProducts(){

  }

  addToCart(userName,productId)
  {

  }

  getCartDetails(userName)
  {

  }

  deleteProductFromCart(userName,productId){}

  searchProductByRange(minPrice,maxPrice){}
}
