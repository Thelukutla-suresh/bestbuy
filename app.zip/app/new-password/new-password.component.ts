import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { CatalogueService } from '../catalogue.service';

@Component({
  selector: 'app-new-password',
  templateUrl: './new-password.component.html',
  styleUrls: ['./new-password.component.css']
})
export class NewPasswordComponent implements OnInit {
  status:Boolean;
  message:string;
  constructor(private router:Router,private catalogueService:CatalogueService) { }

  ngOnInit() {
  }

  onSubmit(form){
    this.catalogueService.changePassword(form).subscribe((data:Boolean)=>{
      this.status=data;
      if(this.status){
        this.router.navigate(['/login']);
      }
      else{
        this.message="Unable to change!!!!";
      }
    });
    
  }

}
