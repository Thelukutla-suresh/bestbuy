import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { CatalogueService } from '../catalogue.service';

@Component({
  selector: 'app-new-password',
  templateUrl: './new-password.component.html',
  styleUrls: ['./new-password.component.css']
})
export class NewPasswordComponent implements OnInit {

  constructor(private router:Router,private catalogueService:CatalogueService) { }

  ngOnInit() {
  }

  onSubmit(form){
    this.catalogueService.changePassword(form);
  }

  recreate(){
    this.router.navigate(['/login']);
  }
}
