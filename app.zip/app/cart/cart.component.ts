import { Component, OnInit } from '@angular/core';
import { CatalogueService } from '../catalogue.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  products:any[];
  totalPrice:any;
  orderDetails:any[];
  message:any;
  constructor(private catalogueService:CatalogueService,private router:Router) { }

  ngOnInit() {
    this.catalogueService.getCartDetails().subscribe((data:any)=>{
      this.products=data;
      if(this.products==null){
        this.message="Cart is empty";
      }
    });
    this.catalogueService.getTotalPrice().subscribe((data:any)=>{
      this.totalPrice=data;
    });
  }
  deleteFromCart(id){
    console.log(id);
    this.catalogueService.deleteProductFromCart(id).subscribe((data:any)=>{
      this.products=data;
      if(this.products==null){
      }
    });
    this.catalogueService.getTotalPrice().subscribe((data:any)=>{
      this.totalPrice=data;
    });
  }

  confirmOrder(){
    this.catalogueService.confirmOrder().subscribe((data:any[])=>{
      this.orderDetails=data;
      this.catalogueService.setOrderDetails(this.orderDetails);
    });
    this.catalogueService.getTotalPrice().subscribe((data:any)=>{
      this.totalPrice=data;
    });
    this.router.navigate(['/order']);
  }
  
  
}
