import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CatalogueService } from '../catalogue.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  status:Boolean;
  message:string;
  constructor(private router:Router,private catalogueService:CatalogueService) { }

  ngOnInit() {
  }

  onSubmit(form){
    this.catalogueService.forgotPassword(form).subscribe((data:Boolean)=>{
      this.status=data;
      console.log(this.status);
      if(this.status)
      {
        this.router.navigate(['/password']);
      }
      else{
        this.message="Wrong Credentials";
      }
    });
  }
}
