import { Component, OnInit } from '@angular/core';
import { CatalogueService } from '../catalogue.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
  products:any[];
  constructor(private catalgoueService:CatalogueService) { }

  ngOnInit() {
    this.catalgoueService.getOrderDetails().subscribe((data:any)=>{
      this.products=data;
    });
  }

}
