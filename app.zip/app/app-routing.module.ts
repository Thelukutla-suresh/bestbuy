import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { NewPasswordComponent } from './new-password/new-password.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { AdminComponent } from './admin/admin.component';
import { ProductComponent } from './product/product.component';
import { AddProductComponent } from './add-product/add-product.component';
import { combineLatest } from '../../node_modules/rxjs';
import { CustomerComponent } from './customer/customer.component';
import { DisplayProductComponent } from './display-product/display-product.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { CartComponent } from './cart/cart.component';
import { OrderComponent } from './order/order.component';


const routes: Routes = [
  { path:'home',component:DisplayProductComponent },
  {path:'welcome',component:HomeComponent},
  { path:'login',component:LoginComponent },
  { path:'password',component:NewPasswordComponent },
  { path:'register',component:RegisterComponent },
  {path:'forgot',component:ForgotPasswordComponent},
  {path:"admin",component:AdminComponent},
  {path:"product",component:ProductComponent},
  {path:"addproduct",component:AddProductComponent},
  {path:"logout",component:HomeComponent},
  {path:"customer",component:DisplayProductComponent},
  {path:"about",component:AboutComponent},
  {path:"contact",component:ContactComponent},
  {path:"cart",component:CartComponent},
  {path:"order",component:OrderComponent},
  { path:'**',redirectTo:'/welcome',pathMatch:'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
