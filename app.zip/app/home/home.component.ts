import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CatalogueService } from '../catalogue.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  constructor(private router:Router, private catalogueService:CatalogueService) { }

  ngOnInit() {
    this.catalogueService.setCustomer(null);
  }

  register() {
    console.log("hiii");
    this.router.navigate(["/register"]);
  }
  
  login(){
    this.router.navigate(['/login']);
  }

}
