import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CatalogueService } from '../catalogue.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private catalogueService:CatalogueService,private router:Router) { }

  ngOnInit() {
  }

  onSubmit(userForm:any)
  {
    this.catalogueService.registerCustomer(userForm);
    this.router.navigate(['/login']);
  }
}
