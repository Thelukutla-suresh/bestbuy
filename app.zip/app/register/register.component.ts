import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CatalogueService } from '../catalogue.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  message:string;
  status:Boolean;
  constructor(private catalogueService:CatalogueService,private router:Router) { }

  ngOnInit() {
  }

  onSubmit(userForm:any)
  {
    this.catalogueService.registerCustomer(userForm).subscribe((data:Boolean)=>{
      this.status=data;
      if(this.status)
      {
        this.router.navigate(['/login']);
      }
      else{
        this.message="Already a user is registered with this email!!!";
      }
    });    
  }

  back(){
    this.router.navigate(['/welcome']);
  }
}
