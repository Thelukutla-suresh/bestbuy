import { Component, OnInit } from '@angular/core';
import { CatalogueService } from '../catalogue.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  products:any[];
  status:Boolean;
  searchTerm1:any;
  searchTerm:any;
  constructor(private catalogueService:CatalogueService,private router:Router) { }

  ngOnInit() {
    this.catalogueService.getAllProducts().subscribe((data:any)=>{
      this.products=data;
    });
  }

  deleteProduct(id)
  {
    this.catalogueService.deleteProduct(id).subscribe((data:any)=>{
      this.products=data;
    });
  }
  onSubmit(){
    this.searchTerm1=this.searchTerm;
  }
}
