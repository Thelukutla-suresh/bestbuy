import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'product'
})
export class ProductPipe implements PipeTransform {

  transform(product: any[], searchterm: String): any {
    if (!product || !searchterm) {
      return product;
    }
    return product.filter(p => p.productId.toString().startsWith(searchterm.toString())
      || (p.price.toString().startsWith(searchterm.toString())) || (p.productName.toString().startsWith(searchterm.toString()))
      || (p.productCategory.toLowerCase().startsWith(searchterm.toLowerCase())));
  }
}
