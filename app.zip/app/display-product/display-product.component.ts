import { Component, OnInit } from '@angular/core';
import { CatalogueService } from '../catalogue.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-display-product',
  templateUrl: './display-product.component.html',
  styleUrls: ['./display-product.component.css']
})
export class DisplayProductComponent implements OnInit {
  products:any[];
  searchTerm1:any;
  searchTerm:any;
  
  constructor(private catalogueService:CatalogueService,private router:Router) { }

  ngOnInit() {
    this.catalogueService.getAllProducts().subscribe((data:any)=>{
      this.products=data;
    });
  }
  addToCart(id){
    this.catalogueService.addToCart(id).subscribe((data:any[])=>{
      this.catalogueService.setCartDetails(data);
    });
    this.router.navigate(['/cart']);
  }
  onSubmit(){
    this.searchTerm1=this.searchTerm;
  }
}
