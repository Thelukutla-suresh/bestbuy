import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { CatalogueService } from '../catalogue.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  customer:any;
  message:string;
  constructor(private router:Router,private catalogueService:CatalogueService) { }

  ngOnInit() {
  }
  
  onSubmit(loginForm){
    this.catalogueService.loginUser(loginForm).subscribe((data:any)=>{
      this.customer=data;
      if(this.customer!=null)
        {
          this.catalogueService.setCustomer(this.customer);
          if(loginForm.role=="admin"){
            this.router.navigate(['/product']);
          }
          else {
            this.router.navigate(['/customer']);
          }
        }
        else{
          this.message="Invalid UserName or password!!!";
        }
    });
  }

  recreate(){
    this.router.navigate(['/forgot']);
  }
}
