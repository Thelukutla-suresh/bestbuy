package com.cg.ProductOrder.dto;

public class ProductInfoOrder {
	
	private Integer prodId;
	private Double prodPrice;
	
	public ProductInfoOrder() {
	
	}

	public ProductInfoOrder(Integer prodId, Double prodPrice) {
		super();
		this.prodId = prodId;
		this.prodPrice = prodPrice;
	}

	public Integer getProdId() {
		return prodId;
	}

	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}

	public Double getProdPrice() {
		return prodPrice;
	}

	public void setProdPrice(Double prodPrice) {
		this.prodPrice = prodPrice;
	}
	
	
	
	

}
