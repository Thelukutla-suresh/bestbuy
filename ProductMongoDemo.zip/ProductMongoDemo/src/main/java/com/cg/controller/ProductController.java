package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.ProductBean;

import com.cg.service.IProductService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class ProductController {
	
	@Autowired
	IProductService iProductService;
	
	@PostMapping("/addall")
	public ResponseEntity<ProductBean> addAllProducts(@RequestBody ProductBean proBean){
		ProductBean data= iProductService.addProduct(proBean);
		if(data==null) {
			 return new ResponseEntity("No Data Found",HttpStatus.NOT_FOUND);

		 }
		 return new ResponseEntity<ProductBean>(proBean,HttpStatus.OK);
		
	}
	
	@GetMapping("/getall")
	public  ResponseEntity<List<ProductBean>> getAllProducts(){
		List<ProductBean>mylist=iProductService.showProduct();
		if(mylist.isEmpty())
		{
			return new ResponseEntity("No Employee Found",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<ProductBean>>(mylist,HttpStatus.OK);
		
	}
	
	@DeleteMapping("/delete")
	public ResponseEntity deletingProduct(@RequestParam("pid") Integer prodId){
		 Integer data= iProductService.deleteproduct(prodId);
		 if(data==null)
		 {
			 return new ResponseEntity("No Data Found",HttpStatus.NOT_FOUND);
		 }
		 return new ResponseEntity<Integer>(prodId,HttpStatus.OK); 
		
	}
	@PostMapping("/update")
	public ResponseEntity<ProductBean> updatingProducts(@RequestBody ProductBean productBean){
		ProductBean data= iProductService.updateproduct(productBean);
		if(data==null) {
			 return new ResponseEntity("No Data Found",HttpStatus.NOT_FOUND);

		 }
		 return new ResponseEntity<ProductBean>(productBean,HttpStatus.OK); 
		
	}
	
	@GetMapping("/searchId")
	public ResponseEntity<ProductBean> searchingProductId(@RequestParam("pid") Integer prodId){
		 ProductBean data=iProductService.searchId(prodId);
		 if(data==null) {
			 return new ResponseEntity("No Data founnd",HttpStatus.NOT_FOUND);
		 }
		 return new ResponseEntity<ProductBean>(data,HttpStatus.OK);
	}
	
	@GetMapping("/searchcost")
	public ResponseEntity<List< ProductBean>> searchingProductCost(@RequestParam("price") Double price){
		List< ProductBean> data=iProductService.searchCost(price);
		 if(data==null) {
			 return new ResponseEntity("No Data founnd",HttpStatus.NOT_FOUND);
		 }
		 return new ResponseEntity<List< ProductBean>>(data,HttpStatus.OK);
	}
	
	@GetMapping("/searchname")
	public ResponseEntity<List< ProductBean>> searchingProductName(@RequestParam("Name") String prodName){
		List< ProductBean> data=iProductService.searchName(prodName);
		 if(data==null) {
			 return new ResponseEntity("No Data founnd",HttpStatus.NOT_FOUND);
		 }
		 return new ResponseEntity<List< ProductBean>>(data,HttpStatus.OK);
	}
	

}
