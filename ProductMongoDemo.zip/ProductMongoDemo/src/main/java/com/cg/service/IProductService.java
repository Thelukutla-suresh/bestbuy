package com.cg.service;

import java.util.List;

import com.cg.dto.ProductBean;

public interface IProductService {
	public ProductBean addProduct(ProductBean productBean);
	public List<ProductBean> showProduct();
	public Integer deleteproduct(Integer prodId);
	public ProductBean updateproduct(ProductBean productBean);
	public ProductBean searchId(Integer prodId);
	public List<ProductBean> searchCost(Double price);
	public List<ProductBean> searchName(String prodName);

}
