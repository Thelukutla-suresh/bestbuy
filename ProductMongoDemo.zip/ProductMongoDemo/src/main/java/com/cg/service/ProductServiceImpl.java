package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IProductDao;
import com.cg.dto.ProductBean;

@Service
public class ProductServiceImpl implements IProductService{
   @Autowired
	IProductDao productdao;
	
	@Override
	public ProductBean addProduct(ProductBean productBean) {
		// TODO Auto-generated method stub
		return productdao.addProduct(productBean);
	}

	@Override
	public List<ProductBean> showProduct() {
		// TODO Auto-generated method stub
		return productdao.showProduct();
	}

	@Override
	public Integer deleteproduct(Integer prodId) {
		// TODO Auto-generated method stub
		return productdao.deleteproduct(prodId);
	}

	@Override
	public ProductBean updateproduct(ProductBean productBean) {
		// TODO Auto-generated method stub
		return productdao.updateproduct(productBean);
	}

	@Override
	public ProductBean searchId(Integer prodId) {
		// TODO Auto-generated method stub
		return productdao.searchId(prodId);
	}

	@Override
	public List< ProductBean> searchCost(Double price) {
		// TODO Auto-generated method stub
		return productdao.searchCost(price);
	}

	@Override
	public List<ProductBean> searchName(String prodName) {
		// TODO Auto-generated method stub
		return productdao.searchName(prodName);
	}

}
