package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.dto.ProductBean;

@Repository
public class ProductDaoImpl implements IProductDao {
    
	@Autowired
	MongoTemplate mongotemplate;
	
	@Override
	public ProductBean addProduct(ProductBean productBean) {
		// TODO Auto-generated method stub
		return mongotemplate.insert(productBean);
	}

	@Override
	public List<ProductBean> showProduct() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(ProductBean.class);
	}

	@Override
	public Integer deleteproduct(Integer prodId) {
		// TODO Auto-generated method stub
		 ProductBean bean= mongotemplate.findById(prodId, ProductBean.class);
		 mongotemplate.remove(bean);
		return bean.getProdId();
	}

	@Override
	public ProductBean updateproduct(ProductBean productBean) {
		// TODO Auto-generated method stub
		
		return mongotemplate.save(productBean);
	}

	@Override
	public ProductBean searchId(Integer prodId) {
		// TODO Auto-generated method stub
		return mongotemplate.findById(prodId, ProductBean.class);
		
	}

	@Override
	public List< ProductBean> searchCost(Double price) {
		// TODO Auto-generated method stub
		List<ProductBean> bean=  mongotemplate.findAll(ProductBean.class);
		List<ProductBean> mylist =new ArrayList<>();
		
		for (ProductBean productBean : bean) {
			
			
			 int k= Double.compare(productBean.getPrice(), price);
			if(k==0)
			{
				mylist.add(productBean);
				
			}
			
		}
		
		return mylist;
	}

	@Override
	public List<ProductBean> searchName(String prodName) {
		// TODO Auto-generated method stub
		
		List<ProductBean> bean=  mongotemplate.findAll(ProductBean.class);
		List<ProductBean> mylist =new ArrayList<>();
		for (ProductBean productBean : bean) {
		
			if(productBean.getProdName().equals(prodName))
			{
				mylist.add(productBean);
			}
		}
		return mylist;
	}

}
