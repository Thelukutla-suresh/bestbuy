package com.cg.dao;

import java.util.List;

import com.cg.dto.ProductBean;

public interface IProductDao {
	
	public ProductBean addProduct(ProductBean productBean);
	public List<ProductBean> showProduct();
	public Integer deleteproduct(Integer prodId);
	public ProductBean updateproduct(ProductBean productBean);
	public ProductBean searchId(Integer prodId);
	public List<ProductBean> searchCost(Double price);
	public List<ProductBean> searchName(String prodName);
	

}
