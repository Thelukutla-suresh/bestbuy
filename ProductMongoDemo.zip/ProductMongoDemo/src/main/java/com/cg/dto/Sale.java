package com.cg.dto;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "saledata")
public class Sale {
	private Integer saleId;
	private String saleName;
	public Integer getSaleId() {
		return saleId;
	}
	public void setSaleId(Integer saleId) {
		this.saleId = saleId;
	}
	public String getSaleName() {
		return saleName;
	}
	public void setSaleName(String saleName) {
		this.saleName = saleName;
	}
	@Override
	public String toString() {
		return "Sale [saleId=" + saleId + ", saleName=" + saleName + "]";
	}
	public Sale(Integer saleId, String saleName) {
		super();
		this.saleId = saleId;
		this.saleName = saleName;
	}
	public Sale() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
