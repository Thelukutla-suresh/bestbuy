package com.cg.dto;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

@Document(collection = "productdata")
public class ProductBean {
	@Id
	private int prodId;
	private String prodName;
	private Double price;
	@JsonFormat(pattern =  "dd-MM-yyyy")
	private Date expiryDate;
	private Sale saleinfo;
	
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	
	
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	
	  
	public ProductBean(int prodId, String prodName, Double price, Date expiryDate, Sale saleinfo) {
		super();
		this.prodId = prodId;
		this.prodName = prodName;
		this.price = price;
		this.expiryDate = expiryDate;
		this.saleinfo = saleinfo;
	}
	@Override
	public String toString() {
		return "ProductBean [prodId=" + prodId + ", prodName=" + prodName + ", price=" + price + ", expiryDate="
				+ expiryDate + ", saleinfo=" + saleinfo + "]";
	}
	public Sale getSaleinfo() {
		return saleinfo;
	}
	public void setSaleinfo(Sale saleinfo) {
		this.saleinfo = saleinfo;
	}
	public ProductBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
