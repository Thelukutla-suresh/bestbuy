import { Component, OnInit } from '@angular/core';
import { CatalogueService } from '../catalogue.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  selectedFiles: FileList;
  currentFileUpload: File;
  constructor(private router:Router,private catalogueService:CatalogueService) {
    
   }

  ngOnInit() {
  }

  selectFile(event) {
    this.selectedFiles = event.target.files;
  }
  upload() {
     this.currentFileUpload = this.selectedFiles.item(0);
     this.catalogueService.saveProfile(this.currentFileUpload).subscribe(event => {
     });  
     this.selectedFiles = undefined;
   }
   
   back(){
    this.router.navigate(['/product']);
   }
}
