import { Component, OnInit } from '@angular/core';
import { CatalogueService } from '../catalogue.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  products:any[];
  constructor(private catalogueService:CatalogueService) { }

  ngOnInit() {
    this.catalogueService.getCartDetails().subscribe((data:any)=>{
      this.products=data;
    });
  }
  deleteFromCart(id){
    console.log(id);
    this.catalogueService.deleteProductFromCart(id).subscribe((data:any)=>{
      this.products=data;
    });
  }
}
