import { Component, OnInit } from '@angular/core';
import { CatalogueService } from '../catalogue.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-display-product',
  templateUrl: './display-product.component.html',
  styleUrls: ['./display-product.component.css']
})
export class DisplayProductComponent implements OnInit {
  products:any[];
  constructor(private catalogueService:CatalogueService,private router:Router) { }

  ngOnInit() {
    this.catalogueService.getAllProducts().subscribe((data:any)=>{
      this.products=data;
    });
  }
  addToCart(id){
    console.log(id);
    this.catalogueService.addToCart(id);
    this.router.navigate(['/cart']);
  }
}
