package com.catalogue.bean;

public class ProductInfo {
	private String productId;
	private String productName;
	private String url;
	private Double price;
	private String productDescription;
	private String productCategory;
	private String itemVisibility;
	public ProductInfo(String productId, String productName, String url, String productCategory, String category,String productDescription,
			String itemVisibility,Double price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.url = url;
		this.productDescription=productDescription;
		this.productCategory = productCategory;
		this.itemVisibility = itemVisibility;
		this.price=price;
	}
	public ProductInfo() {
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getItemVisibility() {
		return itemVisibility;
	}
	public void setItemVisibility(String itemVisibility) {
		this.itemVisibility = itemVisibility;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}

}
