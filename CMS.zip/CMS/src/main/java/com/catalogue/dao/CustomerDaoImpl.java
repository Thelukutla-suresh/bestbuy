package com.catalogue.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.catalogue.bean.Cart;
import com.catalogue.bean.Customer;
import com.catalogue.bean.OrderInfo;
import com.catalogue.bean.Product;
import com.catalogue.bean.ProductInfo;

@Repository
public class CustomerDaoImpl implements ICustomerDao {

	@Autowired
	MongoTemplate mongoTemplate;
	
	@Override
	public String addDetails(Customer customer) {
		if(checkUser(customer.getEmail())!=null)
			return null;
		mongoTemplate.save(customer);
		return "saved";
	}
	
	@Override
	public Customer checkLoginDetails(String userName, String password) {
		Customer customer=checkUser(userName);
		if(customer==null)
		{
			return null;
		}
		return customer;
	}
	
	@Override
	public Customer addToCart(String userName, String productId) {
		Query query=new Query();
		Customer customer=checkUser(userName);
		if(customer==null)
			return null;
		if(customer.getCart()==null)
		{
			customer.setCart(new Cart());
		} 
		
		Cart cart=customer.getCart();
		
		if(cart.getProductInfo()==null) 
		{
			cart.setProductInfo(new ArrayList<ProductInfo>());
		}
		List<ProductInfo> productList=cart.getProductInfo();
		//to update the product quantity
		query.addCriteria(Criteria.where("productId").is(productId));
		Product product=mongoTemplate.findOne(query,Product.class);
		if(product.getProductId()==null) 
		{
			return null;
		}
		Integer quantity=Integer.parseInt(product.getQuantity())-1;
		product.setQuantity(String.valueOf(quantity));
		Update update=new Update();
		update.set("quantity",product.getQuantity());
		mongoTemplate.updateFirst(query, update, Product.class);
		ProductInfo productInformation = new ProductInfo();
		productInformation.setProductId(product.getProductId());
		productInformation.setProductName(product.getProductName());
		productInformation.setProductCategory(product.getProductCategory());
		productInformation.setUrl(product.getUrl());
		productInformation.setProductDescription(product.getDescription());
		productInformation.setItemVisibility(product.getItemVisibility());
		productInformation.setPrice(Double.parseDouble(product.getPrice()));
		productList.add(productInformation);
		cart.setProductInfo(productList);
		cart.setTotalPrice(cart.getTotalPrice()+Double.parseDouble(product.getPrice()));
		customer.setCart(cart);
		mongoTemplate.save(customer);
		return customer;
	}
	
	public Customer checkUser(String userName) {
		Query query=new Query();
		query.addCriteria(Criteria.where("email").is(userName));
		return mongoTemplate.findOne(query,Customer.class);
	}

	@Override
	public List<ProductInfo> getCartDetails(String userName) {
		Customer customer=checkUser(userName);
		if(customer==null)
			return null;
		Cart cart=customer.getCart();
		return cart.getProductInfo();
	}

	@Override
	public Customer deleteProductFromCart(String userName, String productId) {
		Customer customer=checkUser(userName);
		if(customer==null)
			return null;
		Cart cart=customer.getCart();
		if(cart==null)
			return null;
		List<ProductInfo> productInfo=cart.getProductInfo();
		for (ProductInfo productInfo2 : productInfo) {
			if(productInfo2.getProductId().matches(productId))
			{
				productInfo.remove(productInfo2);
				cart.setTotalPrice(cart.getTotalPrice()-productInfo2.getPrice());
			}
		}

		if(productInfo!=null)
		{
			cart.setProductInfo(productInfo);
		}
		else {
		cart.setProductInfo(null);
		cart.setTotalPrice((double) 0);
		}
		customer.setCart(cart);
		mongoTemplate.save(customer);
		return customer;
	}

	@Override
	public boolean forgotPassword(String userName, Integer securityQuestion, String securityAnswer) {
		Customer customer=checkUser(userName);
		if(customer==null)
			return false;
		if(customer.getSecurityQuestion()==securityQuestion){
			if(customer.getSecurityAnswer().matches(securityAnswer))
				return true;
		}
		return false;
	}

	@Override
	public boolean changePassword(String userName, String password) {
		Customer customer=checkUser(userName);
		if(customer==null)
			return false;
		customer.setPassword(password);
		mongoTemplate.save(customer);
		return true;
	}

	@Override
	public List<Product> searchProductByRange(int minPrice, int maxPrice) {
		List<Product> productList=getAllProducts();
		List<Product> productListSearched=new ArrayList<>();
		for (Product product : productList) {
			if(Double.parseDouble(product.getPrice())>=minPrice&&Double.parseDouble(product.getPrice())<=maxPrice)
			{
				productListSearched.add(product);
			}
		}
		return productListSearched;
	}

	@Override
	public OrderInfo confirmOrder(String userName, List<ProductInfo> productList, Double totalPrice) {
		Customer customer=checkUser(userName);
		if(customer==null)
			return null;
		if(customer.getCart()==null)
		{
			customer.setCart(new Cart());
		}
		Cart cart=customer.getCart();
		OrderInfo orderInfo=customer.getOrderInfo();
		if(orderInfo.getProductInfo()==null) 
		{
			orderInfo.setProductInfo(cart.getProductInfo());
		}
		else
		{
			List<ProductInfo> productInfo=orderInfo.getProductInfo();
			productInfo.addAll(cart.getProductInfo());
			orderInfo.setProductInfo(productInfo);
		}
		//SEND EMAIL
		
		cart.setProductInfo(null);
		cart.setTotalPrice((double) 0);
		customer.setCart(cart);
		customer.setOrderInfo(orderInfo);
		mongoTemplate.save(customer);
		return orderInfo;
	}

	@Override
	public List<Product> getAllProducts() {
		List<Product> productList=mongoTemplate.findAll(Product.class);
		return productList;
	}
}