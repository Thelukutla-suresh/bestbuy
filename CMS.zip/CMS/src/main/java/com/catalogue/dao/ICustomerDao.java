package com.catalogue.dao;

import java.util.List;

import com.catalogue.bean.Customer;
import com.catalogue.bean.OrderInfo;
import com.catalogue.bean.Product;
import com.catalogue.bean.ProductInfo;

public interface ICustomerDao {

	String addDetails(Customer customer);

	Customer checkLoginDetails(String userName, String password);

	Customer addToCart(String userName, String productId);

	List<ProductInfo> getCartDetails(String userName);

	Customer deleteProductFromCart(String userName, String productId);

	boolean forgotPassword(String userName, Integer securityQuestion, String securityAnswer);

	boolean changePassword(String userName, String password);

	List<Product> searchProductByRange(double minPrice, double maxPrice);

	OrderInfo confirmOrder(String userName);

	List<Product> getAllProducts();

	Double getTotalPrice(String userName);

	List<ProductInfo> getOrderDetails(String userName);

}
