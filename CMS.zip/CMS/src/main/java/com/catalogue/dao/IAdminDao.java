package com.catalogue.dao;

import java.util.List;

import com.catalogue.bean.Admin;
import com.catalogue.bean.Product;

public interface IAdminDao {

	String addProductDetails(Product product);

	List<Product> deleteProductById(String productId);

	List<Product> searchProduct(String searchTerm);

	Admin checkLoginDetails(String userName, String password);

	List<Product> getAllProducts();

	Boolean addDetails(Admin admin);

	List<Product> searchProductByRange(double minPrice, double maxPrice);
}
