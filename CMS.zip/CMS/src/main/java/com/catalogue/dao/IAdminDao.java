package com.catalogue.dao;

import java.util.List;

import com.catalogue.bean.Product;

public interface IAdminDao {

	String addProductDetails(Product product);

	String deleteProductById(String productId);

	List<Product> searchProduct(String searchTerm);

	boolean checkLoginDetails(String userName, String password);

	List<Product> getAllProducts();
}
