package com.catalogue.service;

import java.util.List;

import com.catalogue.bean.Customer;
import com.catalogue.bean.OrderInfo;
import com.catalogue.bean.Product;
import com.catalogue.bean.ProductInfo;

public interface ICustomerService {
	String addDetails(Customer customer);
	Customer checkLoginDetails(String userName, String password);
	Customer addToCart(String userName,String prodId);
	List<ProductInfo> getCartDetails(String userName);
	Customer deleteProductFromCart(String userName, String productId);
	boolean forgotPassword(String userName, Integer securityQuestion, String securityAnswer);
	boolean changePassword(String userName, String password);
	List<Product> searchProductByRange(int minPrice, int maxPrice);
	OrderInfo confirmOrder(String userName, List<ProductInfo> productList, Double totalPrice);
	List<Product> getAllProducts();
}
