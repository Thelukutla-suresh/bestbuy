package com.catalogue.service;

import java.util.List;

import com.catalogue.bean.Admin;
import com.catalogue.bean.Product;

public interface IAdminService {

	String addProductDetails(Product product);

	List<Product> deleteProductById(String productId);

	List<Product> searchProduct(String searchTerm);

	Admin checkLoginDetails(String userName, String password);

	List<Product> getAllProducts();

	Boolean addDetails(Admin admin);

}
