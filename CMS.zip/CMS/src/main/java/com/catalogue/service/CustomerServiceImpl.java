package com.catalogue.service;

import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.catalogue.bean.Customer;
import com.catalogue.bean.OrderInfo;
import com.catalogue.bean.Product;
import com.catalogue.bean.ProductInfo;
import com.catalogue.dao.ICustomerDao;

@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerDao customerDao;
	
	@Override
	public String addDetails(Customer customer) {
		customer.setPassword(toEncode(customer.getPassword()));
		return customerDao.addDetails(customer);
	}

	@Override
	public boolean checkLoginDetails(String userName, String password) {
		Customer customer=customerDao.checkLoginDetails(userName,password);
		String customerPassword=toDecode(customer.getPassword());
		if(customerPassword.matches(password))
			return true;
		 return false;
	}

	@Override
	public boolean addToCart(String userName, String productId) {
		return customerDao.addToCart(userName,productId);
	}
	
	public static String toEncode(String message) {
		 return Base64.getEncoder().encodeToString(message.getBytes());
		}
	
	public static String toDecode(String message) {
		byte[] decodedBytes = Base64.getDecoder().decode(message);
		return new String(decodedBytes);
		}

	@Override
	public List<ProductInfo> getCartDetails(String userName) {
		// TODO Auto-generated method stub
		return customerDao.getCartDetails(userName);
	}

	@Override
	public boolean deleteProductFromCart(String userName, String productId) {
		return customerDao.deleteProductFromCart(userName,productId);
	}

	@Override
	public boolean forgotPassword(String userName, String securityQuestion, String securityAnswer) {
		return customerDao.forgotPassword(userName,securityQuestion,securityAnswer);
	}

	@Override
	public boolean changePassword(String userName, String password) {
		password=toDecode(password);
		return customerDao.changePassword(userName,password);
	}

	@Override
	public List<Product> searchProductByRange(int minPrice, int maxPrice) {
		return customerDao.searchProductByRange(minPrice,maxPrice);
	}

	@Override
	public OrderInfo confirmOrder(String userName, List<ProductInfo> productList, Double totalPrice) {
		return customerDao.confirmOrder(userName,productList,totalPrice);
	}

	@Override
	public List<Product> getAllProducts() {
		return customerDao.getAllProducts();
	}
		 
}
