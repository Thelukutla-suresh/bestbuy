package com.catalogue.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.catalogue.bean.Cart;
import com.catalogue.bean.Customer;
import com.catalogue.bean.OrderInfo;
import com.catalogue.bean.Product;
import com.catalogue.bean.ProductInfo;
import com.catalogue.service.ICustomerService;

@RestController
@RequestMapping("/customer")
@CrossOrigin(origins = "http://localhost:4200") 
public class CustomerController {

	@Autowired
	ICustomerService customerService;
	
	@GetMapping("/getallproducts")
	public List<Product> getAllProducts(){
		List<Product> productList=customerService.getAllProducts();
		if(productList==null) {
			return null;
		}
		return productList;
	}
	
	@PostMapping("/register")
	public Boolean registerCustomer(@RequestBody Customer customer) {
		System.out.println("register");
		if(customerService.addDetails(customer) != null)
			return true;
		return false;
	}
	
	@GetMapping("/login")
	public Customer checkLoginDetails(@RequestParam String username, String password){
		Customer customer=customerService.checkLoginDetails(username,password);
		if( customer!= null)
		{
			System.out.println(customer.getCustomerName());
			return customer;
		}
		return null;
	}
	
	@GetMapping("/cart")
	public Customer addToCart(@RequestParam String userName, String productId){
		Customer customer=customerService.addToCart(userName,productId);
			if(customer!=null)
				return customer;
			return null;
	}
	
	@GetMapping("/getcartdetails")
	public List<ProductInfo> getCartDetails(@RequestParam String userName){
		List<ProductInfo> productList =customerService.getCartDetails(userName);
		if(productList!=null) {
			return productList;
		}
		return null;
	}
	
	@DeleteMapping("/deleteproductfromcart")
	public List<ProductInfo> deleteProductFromCart(@RequestParam String userName,String productId){
		Customer customer=customerService.deleteProductFromCart(userName,productId);
		if(customer!=null) {
			return customer.getCart().getProductInfo();
		}
		return null;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/searchproductsbypricerange")
	public ResponseEntity<List<Product>> searchProductsByRange(@RequestParam int minPrice,int maxPrice){
		List<Product> productList=customerService.searchProductByRange(minPrice,maxPrice);
		if(productList==null) {
			return new ResponseEntity("No products found",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(productList,HttpStatus.OK);
	}
	
	@GetMapping("/forgotpassword")
	public Boolean forgotPassword(@RequestParam String userName, Integer securityQuestion, String securityAnswer)
	{
		if(customerService.forgotPassword(userName,securityQuestion,securityAnswer)) 
		{
			return true;
		}
		return false;
	}
	
	@GetMapping("/changepassword")
	public Boolean changePassword(@RequestParam String userName,String password){
		if(customerService.changePassword(userName,password)) {
			return true;
		}
		return false;
	}
	
	@SuppressWarnings("rawtypes")
	@PostMapping("/confirmorder")
	public ResponseEntity<OrderInfo> confirmOrder(@RequestBody String userName, List<ProductInfo> productList,Double totalPrice){
		OrderInfo orderInfo=customerService.confirmOrder(userName,productList,totalPrice);
		if(orderInfo!=null) {
			return new ResponseEntity<OrderInfo>(orderInfo,HttpStatus.OK);
		}
		return new ResponseEntity("Unsuccessful order",HttpStatus.NOT_IMPLEMENTED);
	}
}
