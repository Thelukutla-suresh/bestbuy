package com.catalogue.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.catalogue.bean.Customer;
import com.catalogue.bean.OrderInfo;
import com.catalogue.bean.Product;
import com.catalogue.bean.ProductInfo;
import com.catalogue.service.ICustomerService;

@RestController
@RequestMapping("/customer")
@CrossOrigin(origins = "http://localhost:4200") 
public class CustomerController {

	@Autowired
	ICustomerService customerService;
	
	@GetMapping("/getallproducts")
	public List<Product> getAllProducts(){
		List<Product> productList=customerService.getAllProducts();
		if(productList==null) {
			return null;
		}
		return productList;
	}
	
	@PostMapping("/register")
	public Boolean registerCustomer(@RequestBody Customer customer) {
		if(customerService.addDetails(customer) != null)
			return true;
		return false;
	}
	
	@GetMapping("/login")
	public Customer checkLoginDetails(@RequestParam String username, String password){
		Customer customer=customerService.checkLoginDetails(username,password);
		if( customer!= null)
		{
			return customer;
		}
		return null;
	}
	
	@GetMapping("/cart")
	public List<ProductInfo> addToCart(@RequestParam String userName, String productId){
		Customer customer=customerService.addToCart(userName,productId);
		System.out.println(customer.getCart().getProductInfo());
		if(customer!=null)
		{
				return customer.getCart().getProductInfo();
		}
		return null;
	}
	
	@GetMapping("/getcartdetails")
	public List<ProductInfo> getCartDetails(@RequestParam String userName){
		List<ProductInfo> productList =customerService.getCartDetails(userName);
		if(productList!=null) {
			return productList;
		}
		return null;
	}
	
	@DeleteMapping("/deleteproductfromcart")
	public List<ProductInfo> deleteProductFromCart(@RequestParam String userName,String productId){
		Customer customer=customerService.deleteProductFromCart(userName,productId);
		if(customer!=null) {
			return customer.getCart().getProductInfo();
		}
		return null;
	}
	
	@GetMapping("/searchproductsbypricerange")
	public List<Product> searchProductsByRange(@RequestParam double minPrice,double maxPrice){
		List<Product> productList=customerService.searchProductByRange(minPrice,maxPrice);
		if(productList==null) {
			return null;
		}
		return productList;
	}
	
	@GetMapping("/forgotpassword")
	public Boolean forgotPassword(@RequestParam String userName, Integer securityQuestion, String securityAnswer)
	{
		if(customerService.forgotPassword(userName,securityQuestion,securityAnswer)) 
		{
			return true;
		}
		return false;
	}
	
	@GetMapping("/changepassword")
	public Boolean changePassword(@RequestParam String userName,String password){
		if(customerService.changePassword(userName,password)) {
			return true;
		}
		return false;
	}
	
	@GetMapping("/confirmorder")
	public OrderInfo confirmOrder(@RequestParam String userName){
		OrderInfo orderInfo=customerService.confirmOrder(userName);
		if(orderInfo!=null) {
			return orderInfo;
		}
		return null;
	}
	
	@GetMapping("/gettotalprice")
	public Double getTotalPrice(@RequestParam String userName) {
		return customerService.getTotalPrice(userName);
	}
	
	@GetMapping("/orderdetails")
	public List<ProductInfo> orderDetails(@RequestParam String userName){
		return customerService.getOrderDetails(userName);
	}
}
