import { Component } from '@angular/core';
import { EmployeeService } from './app.employeeservice';

@Component({
    selector: 'search-comp',
    templateUrl: 'app.searchcomponent.html'
})

export class SearchEmployeeComponent {

    constructor(private service:EmployeeService) {}

    model: any={};

    searchEmployee():any {
        console.log(this.model);
        this.service.searchEmployee(this.model).subscribe();
    }
}