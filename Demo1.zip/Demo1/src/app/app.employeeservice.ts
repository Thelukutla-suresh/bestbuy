import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class EmployeeService {

    constructor(private http:HttpClient) {}

    getAllEmployees() {
        return this.http.get("http://localhost:5555/emplist/getalldata");
    }

    addEmployee(data:any) {
        /* let input=new FormData();
        input.append("empId", data.eid);
        input.append("empName", data.ename);
        input.append("empSalary", data.esalary);
        */
       let input={"empId":data.eid, "empName":data.ename, "empSalary":data.esalary};
        return this.http.post("http://localhost:5555/emplist/adddata",input);
    }

    updateEmployee(data:any) {

        let input={"empId":data.eid, "empName":data.ename, "empSalary":data.esalary};
        return this.http.post("http://localhost:5555/emplist/update",input);
    }

    searchEmployee(data:any) {
        let input={"empId":data.eid};
        return this.http.get("http://localhost:5555/emplist/update")
    }

    deleteEmployee(id:any) {
        return this.http.delete("http://localhost:5555/emplist/deletedata/"+id)
    }
}