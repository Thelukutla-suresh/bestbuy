import { Component } from '@angular/core';
import { EmployeeService } from './app.employeeservice';

@Component({
    selector:'delete-comp',
    templateUrl:'app.deletecomponent.html'
})

export class DeleteEmployeeComponent{

    data1:any={};
    id:number;

    constructor(private employeeService:EmployeeService){}

    /* ngOnInit(){
        this.employeeService.getAllEmployees().subscribe((data)=>this.data1=data);
    } */

    deleteEmployee(){
        this.employeeService.deleteEmployee(this.id).subscribe((data)=>this.data1=this.data1.filter(u=>u!=this.id))
    }
}