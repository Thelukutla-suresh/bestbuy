import { Component } from '@angular/core';
import { EmployeeService } from './app.employeeservice';

@Component({
    selector: 'update-comp',
    templateUrl: 'app.updatecomponent.html'
})

export class UpdateEmployeeComponent {

    constructor(private service:EmployeeService) {}

    model: any={};

    updateEmployee():any {
        console.log(this.model);
        this.service.updateEmployee(this.model).subscribe();
    }
}