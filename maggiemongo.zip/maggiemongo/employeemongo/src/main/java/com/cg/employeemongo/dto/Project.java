package com.cg.employeemongo.dto;

public class Project {
	private String projectTitle;
	private Integer noOfEmployees;
	public String getProjectTitle() {
		return projectTitle;
	}
	public void setProjectTitle(String projectTitle) {
		this.projectTitle = projectTitle;
	}
	public Integer getNoOfEmployees() {
		return noOfEmployees;
	}
	public void setNoOfEmployees(Integer noOfEmployees) {
		this.noOfEmployees = noOfEmployees;
	}
	@Override
	public String toString() {
		return "Project [projectTitle=" + projectTitle + ", noOfEmployees=" + noOfEmployees + "]";
	}
	public Project(String projectTitle, Integer noOfEmployees) {
		super();
		this.projectTitle = projectTitle;
		this.noOfEmployees = noOfEmployees;
	}
	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
