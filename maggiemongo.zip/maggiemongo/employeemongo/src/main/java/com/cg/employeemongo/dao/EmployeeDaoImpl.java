package com.cg.employeemongo.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.employeemongo.dto.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@Autowired
	MongoTemplate mongotemplate;

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		
		return mongotemplate.findAll(Employee.class);
	}

	@Override
	public Employee addAllEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return mongotemplate.insert(emp);
	}

	@Override
	public Employee searchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		/* return mongotemplate.findById(empId, Employee.class); */
		Query query=Query.query(Criteria.where("empId").is(empId));
		Employee emp=mongotemplate.findOne(query, Employee.class);
		return emp;
		/*
		 * Query query=Query.query(Criteria.where("empId").is(empId)); Employee
		 * emp=mongotemplate.findOne(query, Employee.class); return emp;
		 */
		/*
		 * Query
		 * query=Query.query(Criteria.where("empSalary").gte(5000).and("empName").equals
		 * ("vamsi"));
		 * List<Employee> emp=mongotemplate.find(query,Employee.class);
		 */
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		 return mongotemplate.save(emp);
		 
	}

	@Override
	public void deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		Employee emp=mongotemplate.findById(empId, Employee.class);
		mongotemplate.remove(emp);
	}

}
